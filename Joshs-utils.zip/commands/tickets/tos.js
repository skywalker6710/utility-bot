const { MessageEmbed } = require('discord.js')

module.exports = {
  name: "tos",
  run: async (client, message, args) => {
    message.delete()
    const embed = new MessageEmbed()
    .setDescription('Before we continue this purchase please review our <Channel> and type I Agree in this channel if you agree and would like to continue the purchase')
    .setColor("BLUE")

    message.channel.send(embed)
  }
}