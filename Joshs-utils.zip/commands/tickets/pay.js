const { MessageEmbed } = require('discord.js')

module.exports = {
  name: "pay",
  run: async (client, message, args) => {
    message.delete()

    const paypal = args.slice(1).join(" ")

    if(!args[0]) return message.channel.send('Please provide a amount to send')

    if(!paypal) return message.channel.send('Please provide a link to send the money to')

    const embed = new MessageEmbed()
    .setDescription(`Please pay **$${args[0]}** to the following PayPal Link **${paypal}**.\nOnce you have sent the money please provide a screenshot of the confirmation screen.`)
    .setColor("RANDOM")

    message.channel.send(embed)
  }
}