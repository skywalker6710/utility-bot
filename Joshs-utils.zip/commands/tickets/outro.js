const { MessageEmbed } = require('discord.js');
module.exports = {
  name: "close",
  category: "info",
  description: "Shows how many servers the bot is in",
    run: async (client, message, args) => {
      message.delete()
      const embed = new MessageEmbed()
      .setDescription(`Thank you for creating a ticket with us today. Is there anything else we can do for you today?`)
      .setColor("BLUE")
      message.channel.send(embed)
 }
}