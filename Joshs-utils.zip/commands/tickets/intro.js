const { MessageEmbed } = require('discord.js');
module.exports = {
  name: "intro",
  category: "info",
  description: "Shows how many servers the bot is in",
    run: async (client, message, args) => {
      message.delete()
      const embed = new MessageEmbed()
      .setDescription(`Hello My name is <@${message.author.id}> with ${message.guild.name}. How may I help you today?`)
      .setColor("RED")
      message.channel.send(embed)
 }
}