const { MessageEmbed } = require('discord.js');
module.exports = {
  name: "modlog",
  category: "moderation",
  description: "Sets the channel that moderation will be logged in",
    run: async (client, message, args) => {
      
    }
};