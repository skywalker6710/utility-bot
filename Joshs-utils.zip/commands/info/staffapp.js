const { MessageEmbed } = require('discord.js');
module.exports = {
  name: "staff-app",
  category: "info",
  description: "Lets you apply for staff",
    run: async (client, message, args) => {
}}