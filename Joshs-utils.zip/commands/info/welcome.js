const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
	const m = await message.channel.send("welcome!e");
	m.edit(`***Welcome to this server*** thank you joining tis discord server we are getting more members everyday`);
};

module.exports.help = {
	name: "welcome"
};